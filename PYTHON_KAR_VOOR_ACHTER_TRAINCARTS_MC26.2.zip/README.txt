Minecraft 26.2
TrainCarts category/namespace: python
Models: python:kar_achter and python:kar_voor
/train model search-option compacting false
/train model search
